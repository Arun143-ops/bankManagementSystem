#include<iostream>
#include<fstream>
#include<cctype>
#include<iomanip>
using namespace std;



class BankAccount
{
	int accountNo_;
	char customerName_[50];
	int deposit;
	char type;
  char address_;
public:
	void CreateAccount();	//function to get data from user
	void ShowAccount() ;	//function to show data on screen
	void ModifyData();	//function to add new data
	void DepositMoney(int);	//function to accept amount and add to balance amount
	void WithDraw(int);	//function to accept amount and subtract from balance amount
	void FinalData() ;	//function to show data in tabular format
	int getAccountNumber() ;	//function to return account number
	int getDepositMoney() ;	//function to return balance amount
	char getAccountType() ;	
  char getAddress();//function to return type of account
};         //class ends here

void BankAccount::CreateAccount()
{
	cout<<"\nEnter The account No. :";
	cin>>accountNo_;
	cout<<"\n\nEnter The customerName_ of The account Holder : ";
	cin.ignore();
	cin.getline(customerName_,50);
	cout<<"\nEnter Type of The account (C/S) : ";
	cin>>type;
	type=toupper(type);
	cout<<"\nEnter The Initial amount(>=500 for Saving and >=1000 for current ) : ";
	cin>>deposit;
  cout<<"\nEnter the address of your location:";
  cin>>address_;
  cout<<"\n\n\nAccount Created..";
}

void BankAccount::ShowAccount() 
{
	cout<<"\nAccount No. : "<<accountNo_;
	cout<<"\nAccount Holder customerName_ : ";
	cout<<customerName_;
	cout<<"\nType of Account : "<<type;
  cout<<"\nYour adress is:"<<address_;
	cout<<"\nBalance amount : "<<deposit;
}


void BankAccount::ModifyData()
{
	cout<<"\nAccount No. : "<<accountNo_;
	cout<<"\nModifyData Account Holder customerName_ : ";
	cin.ignore();
	cin.getline(customerName_,50);
	cout<<"\nModifyData Type of Account : ";
	cin>>type;
	type=toupper(type);
	cout<<"\nModifyData Balance amount : ";
	cin>>deposit;
}

	
void BankAccount::DepositMoney(int x)
{
	deposit+=x;
}
	
void BankAccount::WithDraw(int x)
{
	deposit-=x;
}
	
void BankAccount::FinalData() 
{
	cout<<accountNo_<<setw(10)<<" "<<customerName_<<setw(10)<<" "<<type<<setw(10)<<" "<<deposit<<endl;
}

	
int BankAccount::getAccountNumber() 
{
	return accountNo_;
}

int BankAccount::getDepositMoney() 
{
	return deposit;
}

char BankAccount::getAccountType() 
{
	return type;
}

char BankAccount::getAddress()
{
  return address_;
}


//***************************************************************
//    	function declaration
//****************************************************************
void WriteAccount();	//function to write record in binary file
void DisplaySpecificRecord(int);	//function to display account details given by user
void ModifyDataAccount(int);	//function to ModifyData record of file
void DeleteAccount(int);	//function to delete record of file
void DisplayAll();		//function to display all account details
void DepositWithDraw(int, int); // function to desposit/withdraw amount for given account
void intro();	//introductory screen function

//***************************************************************
//    	THE MAIN FUNCTION OF PROGRAM
//****************************************************************


int main()
{
	char ch;
	int num;
	cout<<"\n\n**********";
  cout<<"\n\nWelcome To Banking Management System";
  cout<<"\n\n************";
	do
	{
	
		cout<<"\n\n\n\tMain Menu For Bank Management System";
		cout<<"\n\n\tpress 01. To Create NEW Account";
		cout<<"\n\n\tpress 02. To DEPOSIT AMOUNT";
		cout<<"\n\n\tpress 03. To WITHDRAW AMOUNT";
		cout<<"\n\n\tpress 04. for BALANCE ENQUIRY";
		cout<<"\n\n\tpress 05. show ALL ACCOUNT HOLDER LIST";
		cout<<"\n\n\tpress 06.  To CLOSE AN ACCOUNT";
		cout<<"\n\n\tpress 07. To ModifyData AN ACCOUNT";
		cout<<"\n\n\tpress 08. To EXIT";
		cout<<"\n\n\tSelect Your Option (1-8) :";
		cin>>ch;
	
		switch(ch)
		{
		case '1':
			WriteAccount();
			break;
		case '2':
			cout<<"\n\n\tEnter The account No. : "; cin>>num;
			DepositWithDraw(num, 1);
			break;
		case '3':
			cout<<"\n\n\tEnter The account No. : "; cin>>num;
			DepositWithDraw(num, 2);
			break;
		case '4': 
			cout<<"\n\n\tEnter The account No. : "; cin>>num;
			DisplaySpecificRecord(num);
			break;
		case '5':
			DisplayAll();
			break;
		case '6':
			cout<<"\n\n\tEnter The account No. : "; cin>>num;
			DeleteAccount(num);
			break;
		 case '7':
			cout<<"\n\n\tEnter The account No. : "; cin>>num;
			ModifyDataAccount(num);
			break;
		 case '8':
			cout<<"\n\n\tThanks for using bank managemnt system";
			break;
		 default :cout<<"\a";
		}
		cin.ignore();
		cin.get();
	}while(ch!='8');
	return 0;
}


//***************************************************************
//    	function to write in file
//****************************************************************

void WriteAccount()
{
	BankAccount ac;
	ofstream outFile;
	outFile.open("BankSytem.txt",ios::binary|ios::app);
	ac.CreateAccount();
	outFile.write(reinterpret_cast<char *> (&ac), sizeof(BankAccount));
	outFile.close();
}

//***************************************************************
//    	function to read specific record from file
//****************************************************************

void DisplaySpecificRecord(int n)
{
	BankAccount ac;
	bool flag=false;
	ifstream inFile;
	inFile.open("BankSytem.txt",ios::binary);
	if(!inFile)
	{
		cout<<"File could not be open !! Press any Key...";
		return;
	}
	cout<<"\nBALANCE DETAILS\n";

    	while(inFile.read(reinterpret_cast<char *> (&ac), sizeof(BankAccount)))
	{
		if(ac.getAccountNumber()==n)
		{
			ac.ShowAccount();
			flag=true;
		}
	}
	inFile.close();
	if(flag==false)
		cout<<"\n\nAccount number does not exist!!!";
}


//***************************************************************
//    	function to ModifyData record of file
//****************************************************************

void ModifyDataAccount(int n)
{
	bool found=false;
	BankAccount ac;
	fstream File;
	File.open("BankSytem.txt",ios::binary|ios::in|ios::out);
	if(!File)
	{
		cout<<"File could not be open !! Press any Key...";
		return;
	}
	while(!File.eof() && found==false)
	{
		File.read(reinterpret_cast<char *> (&ac), sizeof(BankAccount));
		if(ac.getAccountNumber()==n)
		{
			ac.ShowAccount();
			cout<<"\n\nEnter The New Details of account:"<<endl;
			ac.ModifyData();
			int pos=(-1)*static_cast<int>(sizeof(BankAccount));
			File.seekp(pos,ios::cur);
			File.write(reinterpret_cast<char *> (&ac), sizeof(BankAccount));
			cout<<"\n\n\t Record Updated";
			found=true;
		  }
	}
	File.close();
	if(found==false)
		cout<<"\n\n Record Not Found ";
}

//***************************************************************
//    	function to delete record of file
//****************************************************************


void DeleteAccount(int n)
{
	BankAccount ac;
	ifstream inFile;
	ofstream outFile;
	inFile.open("BankSytem.txt",ios::binary);
	if(!inFile)
	{
		cout<<"File could not be open !! Press any Key...";
		return;
	}
	outFile.open("Temp.txt",ios::binary);
	inFile.seekg(0,ios::beg);
	while(inFile.read(reinterpret_cast<char *> (&ac), sizeof(BankAccount)))
	{
		if(ac.getAccountNumber()!=n)
		{
			outFile.write(reinterpret_cast<char *> (&ac), sizeof(BankAccount));
		}
	}
	inFile.close();
	outFile.close();
	remove("BankSytem.txt");
	rename("Temp.dat","BankSytem.txt");
	cout<<"\n\n\tRecord Deleted ..";
}

//***************************************************************
//    	function to display all accounts deposit list
//****************************************************************

void DisplayAll()
{
	BankAccount ac;
	ifstream inFile;
	inFile.open("BankSytem.txt",ios::binary);
	if(!inFile)
	{
		cout<<"File could not be open !! Press any Key...";
		return;
	}
	cout<<"\n\n\t\tACCOUNT HOLDER LIST\n\n";
	cout<<"====================================================\n";
	cout<<"A/c no.      customerName_       Type     Balance\n";
	cout<<"====================================================\n";
	while(inFile.read(reinterpret_cast<char *> (&ac), sizeof(BankAccount)))
	{
		ac.FinalData();
	}
	inFile.close();
}

//***************************************************************
//    	function to deposit and withdraw amounts
//****************************************************************

void DepositWithDraw(int n, int option)
{
	int amt;
	bool found=false;
	BankAccount ac;
	fstream File;
	File.open("BankSytem.txt", ios::binary|ios::in|ios::out);
	if(!File)
	{
		cout<<"File could not be open !! Press any Key...";
		return;
	}
	while(!File.eof() && found==false)
	{
		File.read(reinterpret_cast<char *> (&ac), sizeof(BankAccount));
		if(ac.getAccountNumber()==n)
		{
			ac.ShowAccount();
			if(option==1)
			{
				cout<<"\n\n\tTO DEPOSITE AMOUNT ";
				cout<<"\n\nEnter The amount to be deposited:";
				cin>>amt;
				ac.DepositMoney(amt);
			}
			if(option==2)
			{
				cout<<"\n\n\tTO WITHDRAW AMOUNT ";
				cout<<"\n\nEnter The amount to be withdraw:";
				cin>>amt;
				int bal=ac.getDepositMoney()-amt;
				if((bal<500 && ac.getAccountType()=='S') || (bal<1000 && ac.getAccountType()=='C'))
					cout<<"Insufficience balance";
				else
					ac.WithDraw(amt);
			}
			int pos=(-1)*static_cast<int>(sizeof(ac));
			File.seekp(pos,ios::cur);
			File.write(reinterpret_cast<char *> (&ac), sizeof(BankAccount));
			cout<<"\n\n\t Record Updated";
			found=true;
	       }
         }
	File.close();
	if(found==false)
		cout<<"\n\n Record Not Found ";
}

